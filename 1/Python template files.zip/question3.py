def gcd(a, b):
    '''
    ##Comment out print functions if you submit on gradescope.
    @a: the first integer
    @b: the second integer

    @return the greatest common divisor of integer a and b.
    '''
    # To do
    pass

#print(gcd(15, 45))
#print(gcd(45, 15))
