def anagram(string1, string2):
    '''
    ##Comment out print functions if you submit on gradescope.
    @string1: The first string
    @string2: The second string

    @return True if string1 is anagram of string2
            False otherwise
    '''
    # To do
    pass

string1 = "1 23"
string2 = "3 2 1"
#print(anagram(string1, string2))      
        
