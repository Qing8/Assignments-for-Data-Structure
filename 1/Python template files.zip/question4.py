def addOne(digits):
    '''
    ##Comment out print functions if you submit on gradescope.
    @digits: a list of digits
    
    @return a list of digits, which is @digits added 1 to it.
    '''
    # To do
    pass


#print(digits([1,2,3]))
#print(digits([9,9,9]))