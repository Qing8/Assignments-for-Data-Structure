import math   # need math.pi
class Shape:
    # No need to modify this class.
    def __init__(self, name):
        self.name = name

    def compute_area(self):
        pass

    def compute_perimeter(self):
        pass

class Circle(Shape):
    def __init__(self, name, radius):
        # TO DO
        # Call super first

    def compute_area(self):
        # TO DO
        # @return the area of this circle

    def compute_perimeter(self):
        # TO DO
        # @return the perimeter of this circle

class Rectangle(Shape):
    def __init__(self, name, length, height):
        # TO DO
        # Call super first

    def compute_area(self):
        # TO DO
        # @return the area of this rectangle

    def compute_perimeter(self):
        # TO DO
        # @return the area of this rectangle

#c = Circle("Moon", 15)
#print(c.compute_perimeter())
#r = Rectangle("Block", 20, 10)
#print(r.compute_area())



