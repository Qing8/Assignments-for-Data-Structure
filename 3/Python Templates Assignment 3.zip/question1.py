def power(x,n):
    '''
    @x: the base, integer
    @n: the exponent, integer

    x, n can be negative integer.
    # Don't print anything if you want to submit on gradescope!

    @return: x^n
    '''
    pass

#print(power(-2, -3))    # -0.125
#print(power(4, 3))      # 64