def pascal(n):
    '''
    @n: number of levels in pascal triangle

    # Don't print anything if you want to submit on gradescope!


    @return: list of sublists. Each sublist contain a level's values
    '''
    pass



#print(pascal(4))    # [[1], [1, 1], [1, 2, 1], [1, 3, 3, 1]]