def largest_ten(l):
    # Assuming list size greater than 10
    '''
    @l: list of integers
    
    remember to mention your runtime!

    @return: largest ten elements in list l.
    '''
    pass


print(largest_ten([9,8,6,4,22,68,96,212,52,12,6,8,99]))
    
