def count_primes(n):
    '''
    @n: count the number of prime numbers less than n.

    @return: number of prime numbers less than n.
    '''
    pass



print(count_primes(10)) # Should prints 4.