def merge(I1, I2):  
    '''
    @I1: first iterable object. Can be a string!
    @I2: second iterable object.

    @return: alternately merged I1, I2 elements in a list.
    '''      
    pass


print([i for i in merge("what",range(100,105))])
print([i for i in merge(range(5),range(100,101))])
print([i for i in merge(range(1),range(100,105))])