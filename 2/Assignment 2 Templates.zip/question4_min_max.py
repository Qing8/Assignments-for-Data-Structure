def min_max(l):
    '''
    @l: list of integers.

    @return: list, or tuple of two elements. 
    First element is min, second element is max.
    '''
    pass

print(min_max([6,2,5,8,1,-4,6,12,78,21,55,62,1,0]))
